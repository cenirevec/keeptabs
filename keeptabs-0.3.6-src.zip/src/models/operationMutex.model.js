export class operationMutex{
    /** Get the id of the keeptab tab */
    instance = undefined;
    /** Action */
    action = "LOAD";
    /* Timestamp of the operation date */
    date = 1661303532000
}

export default operationMutex;